﻿namespace CarDealer.BindingModels
{
    using System;

    public class AddCustomerBindingModel
    {
        public string Name { get; set; }

        public DateTime Birthdate { get; set; }
    }
}
