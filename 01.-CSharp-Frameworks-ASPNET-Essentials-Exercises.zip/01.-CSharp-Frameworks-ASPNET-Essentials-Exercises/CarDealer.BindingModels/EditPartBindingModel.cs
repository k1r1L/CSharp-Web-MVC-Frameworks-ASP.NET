﻿namespace CarDealer.BindingModels
{
    public class EditPartBindingModel
    {
        public int Id { get; set; }

        public double? Price { get; set; }

        public int  Quantity { get; set; }
    }
}
