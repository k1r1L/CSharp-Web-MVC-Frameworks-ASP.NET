﻿namespace CarDealer.BindingModels
{
    public class AddPartBindingModel
    {
        public string Name { get; set; }

        public double? Price { get; set; }

        public int? Quantity { get; set; }

        public string Supplier { get; set; }
    }
}
