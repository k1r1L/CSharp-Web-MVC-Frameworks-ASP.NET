﻿namespace CarDealer.ViewModels
{
    public class AllPartViewModel
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}
